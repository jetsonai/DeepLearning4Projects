from OpenCV_Functions import *

'''
def drawRect(image, point1, point2, color=(255, 0, 0), thickness=5, lineType=cv2.LINE_AA):
    result = imageCopy(image)
    return cv2.rectangle(result, point1, point2, color, thickness, lineType)
'''

imagePath = "./solidWhiteCurve.jpg"

roadColor = imageRead(imagePath, cv2.IMREAD_COLOR)
imageShow("roadColor", roadColor)

height = roadColor.shape[0]
width = roadColor.shape[1]
pt1 = (0, int(height * 0.6))
pt2 = (width, height)

roadColor_Line_01 = drawLine(roadColor, pt1, pt2, (255, 0, 0))
imageShow("roadColor_Line_01", roadColor_Line_01)

roadColor_Rect_01 = drawRect(roadColor, pt1, pt2, (255, 0, 0))
imageShow("roadColor_Rect_01", roadColor_Rect_01)

roadColor_Rect_02 = drawRect(roadColor, pt1, pt2, (255, 0, 0), -1)
imageShow("roadColor_Rect_02", roadColor_Rect_02)

cv2.destroyAllWindows()
